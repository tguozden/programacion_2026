# Datos del ejercicio

Observaciones de estaciones (datos de ejemplo, formato similar al SMN).

¡Ojo! No todos los archivos tienen el mismo encoding.
